package ua.nure.temnokhud.task3;

import java.io.IOException;

import static java.lang.System.out;

class Demo {

    public static void main(String... args) throws IOException {
        out.println("=== Part 1 ===");
        Part1.main(new String[]{});
        out.println();

        out.println("=== Part 2 ===");
        Part2.main(new String[]{});
        out.println();

        out.println("=== Part 3 ===");
        Part3.main(new String[]{});
        out.println();

        out.println("=== Part 4 ===");
        Part4.main(new String[]{});
        out.println();

        out.println("=== Part 5 ===");
        Part5.main(new String[]{});
        out.println();
    }
}
